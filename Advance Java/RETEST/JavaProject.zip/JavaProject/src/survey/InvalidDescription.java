package survey;

public class InvalidDescription extends Exception {
    public InvalidDescription(String message) {
        super(message);
    }
}
