package survey;

import java.util.List;

public interface IFeedbackService {
    Feedback add(String description, String authorName) throws InvalidDescription, InvalidAuthorName;
    Feedback findById(long feedbackId) throws InvalidIdException, FeedbackNotFoundException;
    List<Feedback> findFeedbacksByAuthorOrderById(String authorName);
}
