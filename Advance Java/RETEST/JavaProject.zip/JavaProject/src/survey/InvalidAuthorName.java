package survey;

public class InvalidAuthorName extends Exception {
    public InvalidAuthorName(String message) {
        super(message);
    }
}
