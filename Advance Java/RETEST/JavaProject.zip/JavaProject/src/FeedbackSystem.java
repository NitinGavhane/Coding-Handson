import java.util.List;
import java.util.Scanner;

import survey.Feedback;
import survey.FeedbackNotFoundException;
import survey.FeedbackService;
import survey.IFeedbackService;
import survey.InvalidAuthorName;
import survey.InvalidDescription;
import survey.InvalidIdException;

public class FeedbackSystem {
    public static void main(String[] args) {
        IFeedbackService feedbackService = new FeedbackService();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nA Maveric Syestems wants to create a survey management system, The application can then be used to take feedbacks on any issue");
            System.out.println("1. Add feedbacks in store");
            System.out.println("2. Find feedback by id");
            System.out.println("3. Find feedbacks by author_name");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.println("Enter Description:");
                    String description = scanner.nextLine();
                    System.out.println("Enter Author Name :");
                    String authorName = scanner.nextLine();

                    try {
                        Feedback feedback = feedbackService.add(description, authorName);
                        System.out.println("\nThis feedback is added....");
                        System.out.println("Author: " + feedback.getAuthor());
                        System.out.println("Feedback: " + feedback.getDescription());
                    } catch (InvalidDescription | InvalidAuthorName e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 2:
                    System.out.println("Enter Feedback ID:");
                    long feedbackId = scanner.nextLong();
                    scanner.nextLine();

                    try {
                        Feedback feedback = feedbackService.findById(feedbackId);
                        System.out.println("Feedback found:");
                        System.out.println("Author: " + feedback.getAuthor());
                        System.out.println("Feedback: " + feedback.getDescription());
                    } catch (InvalidIdException | FeedbackNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 3:
                    System.out.println("Enter Author Name:");
                    String authorToSearch = scanner.nextLine();

                    List<Feedback> authorFeedbacks = feedbackService.findFeedbacksByAuthorOrderById(authorToSearch);
                    if (authorFeedbacks.isEmpty()) {
                        System.out.println("No feedbacks found for author: " + authorToSearch);
                    } else {
                        System.out.println("Feedbacks for author: " + authorToSearch);
                        for (Feedback feedback : authorFeedbacks) {
                            System.out.println("Author: " + feedback.getAuthor());
                            System.out.println("Feedback: " + feedback.getDescription());
                        }
                    }
                    break;

                case 4:
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
            }
        }
    }
}
