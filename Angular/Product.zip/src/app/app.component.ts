import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  products: any[] = [
    { name: 'Radio', description: 'Murfy radio', price: 1000 },
  ];

  newProduct: any = {
    name: '',
    description: '',
    price: 0,
  };

  editIndex: number | null = null;

  addProduct() {
    if (this.newProduct.name && this.newProduct.description && this.newProduct.price >= 0) {
      this.products.push({ ...this.newProduct });
      this.resetForm();
    }
  }

  enableEdit(index: number) {
    this.editIndex = index;
  }

  updateProduct(index: number) {
    this.editIndex = null; 
  }

  deleteProduct(index: number) {
    const confirmDelete = confirm('Are you sure you want to delete this product?');
    if (confirmDelete) {
      this.products.splice(index, 1);
      this.editIndex = null; 
    }
  }

  resetForm() {
    this.newProduct = {
      name: '',
      description: '',
      price: 0,
    };
  }
}
